package net.rubyeye.xmemcached.test.unittest.monitor;

public interface MockMBean {
	public String say(String name);
}
